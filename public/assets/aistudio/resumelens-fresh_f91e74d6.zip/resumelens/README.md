# 📄 ResumeLens — Grounded ATS & Technical Recruiter Audit

**Powered by Google Gemma 4** (via Gemini API / AI Studio)

A production-ready resume analyzer that:
- Extracts **grounded skills** (with evidence from resume)
- Finds skill gaps vs Job Description
- Rewrites weak bullets (XYZ formula)
- Gives a 4-week action plan
- Scores: Keywords • Relevance • Impact • Structure • Formatting
- Runs grounding validation to prevent hallucination

---

## 🚀 Quick Start (Local)

### 1. Get Gemini API Key (Free)
1. Go to → [https://aistudio.google.com/apikey](https://aistudio.google.com/apikey)
2. Create API Key
3. Gemma 4 models (`gemma-4-26b-a4b-it`, `gemma-4-31b-it`) are available through this key

### 2. Setup
```bash
git clone https://github.com/YOUR_USERNAME/resumelens.git
cd resumelens

npm install

# Create .env.local
echo 'GEMINI_API_KEY=your_key_here' > .env.local
```

### 3. Run
```bash
npm run dev
```
Open → http://localhost:3000 (or the port shown)

---

## 📦 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 19 + Vite + Tailwind 4 |
| Backend | Express + tsx |
| AI | `@google/genai` → Gemma 4 models |
| Validation | Zod + custom grounding checks |

---

## 🌐 Deploy

### Option 1: Google AI Studio (easiest)
Already designed for it. Just open the original AI Studio link or redeploy from there.

### Option 2: Vercel / Netlify / Railway
1. Push to GitHub
2. Import project
3. Add environment variable: `GEMINI_API_KEY`
4. Build command: `npm run build`
5. Start command: `npm start` (or use the Express server)

### Option 3: Render / Fly.io
Same as above — set `GEMINI_API_KEY` in secrets.

---

## 🔑 Environment Variables

```env
GEMINI_API_KEY=your_gemini_api_key
```

---

## 📁 Project Structure

```
resumelens/
├── server.ts                 # Express + Gemma 4 API
├── src/
│   ├── App.tsx               # Main UI
│   ├── components/           # Score, Skills, Gaps, Bullet Studio, Action Plan
│   ├── utils/resumeAnalyzer.ts
│   └── types/resume.ts
├── package.json
└── .env.local                # Your key (not committed)
```

---

## ✅ Features

- **Grounded skills** — every skill has evidence quote from resume
- **No fabrication** — bullet rewrites use placeholders if no metrics exist
- **Gap analysis** — required vs preferred, with severity + how to close
- **4-week action plan** with free resources
- **Fallback** deterministic analyzer if model fails
- **Caching** of results for same resume + role

---

## License

MIT
